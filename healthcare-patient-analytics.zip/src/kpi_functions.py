
import pandas as pd

def compute_kpis(df):
    kpis = {}
    kpis['total_admissions'] = len(df)
    kpis['avg_los'] = df['length_of_stay'].mean()
    kpis['median_los'] = df['length_of_stay'].median()
    kpis['readmission_rate'] = df['readmit_30'].mean()
    kpis['admissions_by_dept'] = df.groupby('department').size().sort_values(ascending=False).to_dict()
    return kpis

if __name__ == '__main__':
    df = pd.read_csv('data/admissions.csv', parse_dates=['admit_date','discharge_date'])
    print(compute_kpis(df))
