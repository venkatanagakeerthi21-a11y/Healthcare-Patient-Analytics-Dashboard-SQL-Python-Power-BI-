
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def plot_admissions_over_time(df, out='dashboard/screenshots/admissions_over_time.png'):
    df['admit_date'] = pd.to_datetime(df['admit_date'])
    series = df.groupby(df['admit_date'].dt.to_period('M')).size()
    plt.figure(figsize=(10,4))
    series.plot()
    plt.title('Monthly Admissions')
    plt.xlabel('Month')
    plt.ylabel('Admissions')
    plt.tight_layout()
    plt.savefig(out)
    plt.close()

def plot_los_distribution(df, out='dashboard/screenshots/los_distribution.png'):
    plt.figure(figsize=(8,4))
    sns.histplot(df['length_of_stay'], bins=20)
    plt.title('Length of Stay Distribution')
    plt.xlabel('Days')
    plt.tight_layout()
    plt.savefig(out)
    plt.close()

if __name__ == '__main__':
    df = pd.read_csv('data/admissions.csv', parse_dates=['admit_date','discharge_date'])
    plot_admissions_over_time(df)
    plot_los_distribution(df)
