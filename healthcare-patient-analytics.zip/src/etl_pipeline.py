
import pandas as pd
from cleaning import load_data, compute_age, merge_admissions

def run_etl(data_dir='data', out_dir='outputs'):
    patients, admissions = load_data(data_dir)
    patients = compute_age(patients)
    merged = merge_admissions(patients, admissions)
    # write outputs
    import os
    os.makedirs(out_dir, exist_ok=True)
    pd.DataFrame(merged).to_csv(f'{out_dir}/admissions_merged.csv', index=False)
    print('Wrote', f'{out_dir}/admissions_merged.csv')
    return merged

if __name__ == '__main__':
    run_etl()
