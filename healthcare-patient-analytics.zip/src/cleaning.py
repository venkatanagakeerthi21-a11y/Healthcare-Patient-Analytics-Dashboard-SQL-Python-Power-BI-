
import pandas as pd
def load_data(data_dir='data'):
    patients = pd.read_csv(f'{data_dir}/patients.csv', parse_dates=['birth_date'])
    admissions = pd.read_csv(f'{data_dir}/admissions.csv', parse_dates=['admit_date','discharge_date'])
    return patients, admissions

def compute_age(patients, reference_date=pd.Timestamp('2024-01-01')):
    patients['birth_date'] = pd.to_datetime(patients['birth_date'])
    patients['age'] = (reference_date - patients['birth_date']).dt.days // 365
    return patients

def merge_admissions(patients, admissions):
    df = admissions.merge(patients, on='patient_id', how='left')
    return df
