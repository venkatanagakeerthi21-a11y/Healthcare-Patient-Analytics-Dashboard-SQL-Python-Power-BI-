
-- admissions_kpi_queries.sql
-- Total admissions
SELECT COUNT(*) AS total_admissions FROM admissions;

-- Average length of stay
SELECT AVG(length_of_stay) AS avg_los FROM admissions;

-- Admissions by department
SELECT department, COUNT(*) AS admissions FROM admissions GROUP BY department ORDER BY admissions DESC;

-- Readmission rate
SELECT SUM(readmit_30) * 1.0 / COUNT(*) AS readmit_rate FROM admissions;
