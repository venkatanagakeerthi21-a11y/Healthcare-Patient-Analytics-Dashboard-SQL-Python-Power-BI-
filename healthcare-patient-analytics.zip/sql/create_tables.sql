
-- create_tables.sql
CREATE TABLE patients (
  patient_id INT PRIMARY KEY,
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  birth_date DATE,
  gender CHAR(1),
  city VARCHAR(100),
  state VARCHAR(10)
);

CREATE TABLE admissions (
  admission_id INT PRIMARY KEY,
  patient_id INT,
  admit_date DATE,
  discharge_date DATE,
  length_of_stay INT,
  department VARCHAR(100),
  primary_diagnosis VARCHAR(100),
  readmit_30 INT
);
