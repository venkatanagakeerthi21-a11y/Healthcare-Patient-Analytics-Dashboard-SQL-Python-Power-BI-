
-- length_of_stay_queries.sql
-- Median LOS (example using window function)
SELECT DISTINCT percentile_cont(0.5) WITHIN GROUP (ORDER BY length_of_stay) OVER () AS median_los FROM admissions;
