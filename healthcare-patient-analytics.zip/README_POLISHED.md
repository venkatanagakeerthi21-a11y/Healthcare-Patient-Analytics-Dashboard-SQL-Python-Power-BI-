
# Healthcare Patient Admissions & Length-of-Stay Analytics Dashboard

**Author:** Keerthi Chennu — venkatanagakeerthi21@gmail.com

## Project Summary
This project analyzes hospital patient admissions to derive operational KPIs including **Length of Stay (LOS)**, **readmission rate**, and **department-level admissions**. It showcases full data lifecycle: SQL, Python ETL, EDA, KPI calculations, and dashboard-ready visualizations. Synthetic data is used for demonstration — replace with real hospital data for production use.

## Repository Contents
- `data/` — CSV datasets (patients, admissions, departments, diagnoses)  
- `src/` — Python scripts to run ETL and generate visuals  
- `sql/` — SQL scripts for table creation and KPI queries
- `notebooks/` — Jupyter notebooks for EDA and cleaning
- `dashboard/screenshots/` — generated PNG visualizations
- `reports/` — writeups and summaries

## How to run
```bash
pip install -r requirements.txt
bash run_project.sh
```

## Key KPIs & Methods
- **Total admissions** — SQL `COUNT(*)` and Pandas `.shape`  
- **Average & Median LOS** — `AVG(length_of_stay)` and `median` (Pandas)  
- **Readmission Rate (30-day)** — proportion of admissions flagged `readmit_30`  
- **Admissions by Department** — group-by aggregation and time-series trends

## Example Insights (from synthetic data)
- Average LOS: **4.09 days  
- Median LOS: **3 days  
- Total admissions: **772**

## Visualizations
Screenshots are saved in `dashboard/screenshots/`. Example charts:


## Files to include in GitHub
- CSV datasets (data/) — small, synthetic or sampled
- Jupyter notebooks showing EDA & code (notebooks/)
- Python scripts for ETL & visualizations (src/)
- SQL scripts for table creation and KPI queries (sql/)
- README (this file) and a concise project summary in your profile

---
## Notes for Recruiters
This project demonstrates practical skills in data cleaning, SQL-based KPI reporting, Python ETL, and dashboard creation ideal for Data Analyst and BI roles in healthcare and operations.
