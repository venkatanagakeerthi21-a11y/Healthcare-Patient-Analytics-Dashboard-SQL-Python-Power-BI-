
#!/bin/bash
python src/etl_pipeline.py
python src/visualizations.py
echo "Outputs created in outputs/ and dashboard/screenshots/"
