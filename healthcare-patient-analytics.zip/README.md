
# Healthcare Patient Admissions & Length-of-Stay Analytics Dashboard

**Overview**
This repository contains a reproducible end-to-end data analytics project that analyzes hospital patient admissions and length-of-stay (LOS) metrics. It includes synthetic datasets, SQL queries, Python ETL scripts, Jupyter notebooks, and visualization assets suitable for a GitHub portfolio.

**Files & Structure**
```
healthcare-patient-analytics/
├── data/                      # CSV datasets
├── notebooks/                 # Jupyter notebooks (analysis & EDA)
├── sql/                       # SQL scripts for key KPIs
├── src/                       # Python scripts (ETL, cleaning, KPIs, viz)
├── dashboard/                 # BI file + screenshots
├── reports/                   # PDF summaries
├── README.md
├── requirements.txt
└── LICENSE
```

**Datasets**
- `data/patients.csv` — patient demographics
- `data/admissions.csv` — admission records with admit/discharge dates and LOS
- `data/departments.csv` — department lookup
- `data/diagnoses.csv` — diagnosis lookup

**How to run**
1. Create a Python environment and install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run ETL and produce merged outputs:
   ```bash
   python src/etl_pipeline.py
   ```
3. Generate visualizations:
   ```bash
   python src/visualizations.py
   ```
4. Open `dashboard/powerbi_dashboard.pbix` in Power BI (if provided) or view screenshots in `dashboard/screenshots/`.

**Key KPIs**
- Total admissions
- Average & median Length of Stay (LOS)
- Readmission rate (30-day)
- Admissions by department
- Monthly admission trends

**Notes**
- This project uses *synthetic* data for demonstration. Replace `data/*.csv` with real datasets for production analysis.
- The Power BI file is not included due to binary size; include screenshots or a link to an online report.

**Contact**
Keerthi Chennu — venkatanagakeerthi21@gmail.com
